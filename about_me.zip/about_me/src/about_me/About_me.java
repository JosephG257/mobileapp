/**
 * 
 */
package about_me;

/**
 * @author josephine.garner
 *
 */
public class About_me {

	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Im Joseph Garner");
		System.out.println("1st Period-Color Guard");
		System.out.println("2nd-Math Decsion Making");
		System.out.println("3rd-Fin Lit");
		System.out.println("4th-Creative Writing");
		System.out.println("5th-Sociology");
		System.out.println("6th/7th-Mobile App");
		System.out.println("8th-ASL 3rd year");
		System.out.println("9th-Credit Recovery");
		System.out.println("10th-Int. Chorus");
		System.out.println("This is my first semesters classes for my senior year");
		
	}

}
