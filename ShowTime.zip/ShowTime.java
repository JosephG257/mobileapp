// Joseph Garner
// 8/30/2019

import java.util.Calendar;
import static java.lang.System.out;

public class ShowTime 
{
public static void main(String[] args) 
   {
	out.println(Calendar.getInstance().getTime());
   }
}
